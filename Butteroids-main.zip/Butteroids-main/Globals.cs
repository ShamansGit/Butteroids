using Godot;
using System;
[Obsolete]
//Obsolete, use GameManager for global variables
public partial class Globals : Node
{
    //[Export]
    //public Vector2 mapSize;
}
