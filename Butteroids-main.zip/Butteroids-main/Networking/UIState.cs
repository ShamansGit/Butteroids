public enum UIState
{
    NotConnected,
    JoiningAsClient,
    ConnectedAsHost,
    ConnectedAsClient,
    InGame,
}