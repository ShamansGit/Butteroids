//note: the tutorial uses a class not a struct.
using Godot;

public class PlayerInfo{
    public string Name = "Name not set";
    public Color color = new Color("white");
    public int lives = 3;
}